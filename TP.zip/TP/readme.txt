1.Hello everyone, my final project for the course 15112 is called miniFIFAonline3
The main purpose of my project is to make people have fun in their free time
2.In order to run this game your just need to run the __init__ file, and the game will run automatically run
3. Besides, you need to install pygame module in order to run it
4 shortcut commands : press "s" on keyboard to change players or passball
                      press "d" on keyboard to steal ball or shoot
                      press "a" on keyboard to cross ball
                      press "e" on keyboard to speed up the player you currently control
                      press 'up', 'down', 'left', 'right', 'up' + 'left',
                       'up' + 'right', 'down' + 'left', 'down' + 'right' on keyboard to control players
                      press "r" on keyboard to restart the game

